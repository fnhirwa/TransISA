	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #1024
	str	xzr, [x19, #16]
	str	w8, [x19, #8220]
	mov	w8, #1
	str	w8, [x19, #12]
LBB0_1:
	ldr	w11, [x19, #12]
	sub	w9, w11, #5
	cmp	w9, #0
	cset	w10, lt
	cmp	w11, #0
	cset	w11, lt
	cbz	w9, LBB0_3
	lsr	w9, w9, #31
	eor	w10, w11, w10
	cmp	w9, w10
	b.eq	LBB0_7
LBB0_3:
	mov	x10, sp
	sub	x9, x10, #16
	mov	sp, x9
	stur	w8, [x10, #-16]
	b	LBB0_5
LBB0_4:
	mov	x10, sp
	sub	x11, x10, #16
	mov	sp, x11
	ldur	w11, [x10, #-16]
	add	w11, w11, #1
	stur	w11, [x10, #-16]
LBB0_5:
	ldr	w12, [x9]
	mov	x13, sp
	sub	x14, x13, #16
	sub	w10, w12, #4
	cmp	w10, #0
	cset	w11, lt
	cmp	w12, #0
	cset	w12, lt
	mov	sp, x14
	ldur	w14, [x13, #-16]
	add	w14, w14, #1
	stur	w14, [x13, #-16]
	cbz	w10, LBB0_4
	lsr	w10, w10, #31
	eor	w11, w12, w11
	cmp	w10, w11
	b.ne	LBB0_4
	b	LBB0_1
LBB0_7:
Lloh0:
	adrp	x9, _result@PAGE
Lloh1:
	add	x9, x9, _result@PAGEOFF
	mov	w11, #1
	ldr	w8, [x19, #16]
	ldr	w10, [x9]
	movk	w11, #512, lsl #16
	add	w12, w11, #3
	str	w8, [x10]
	stp	w8, w12, [x19, #12]
	mov	x8, sp
	sub	x10, x8, #16
	mov	sp, x10
	mov	x12, sp
	mov	w10, #1
	sub	x13, x12, #16
	stur	w10, [x8, #-16]
	mov	sp, x13
	stur	x9, [x12, #-16]
	mov	x9, sp
	sub	x13, x9, #16
	mov	sp, x13
	mov	x13, xzr
	ldr	w14, [x19, #16]
	mov	w15, w10
	ldur	x16, [x12, #-16]
	stur	w10, [x9, #-16]
	; InlineAsm Start
	mov	x16, x14
	mov	x0, x15
	mov	x1, x16
	mov	x2, x10
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x10, x0
	; InlineAsm End
	ldr	w10, [x19, #12]
	ldur	x12, [x12, #-16]
	ldur	w9, [x9, #-16]
	str	w11, [x19, #16]
	stur	w10, [x8, #-16]
	; InlineAsm Start
	mov	x16, x11
	mov	x0, x10
	mov	x1, x12
	mov	x2, x9
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	sub	sp, x29, #16
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
