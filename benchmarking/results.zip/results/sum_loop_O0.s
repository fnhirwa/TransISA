	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #1024
	str	xzr, [x19, #16]
	str	w8, [x19, #8220]
	mov	w8, #1
	str	w8, [x19, #12]
LBB0_1:
	ldp	w9, w8, [x19, #12]
	add	w8, w8, w9
	mov	x9, sp
	str	w8, [x19, #16]
	sub	x8, x9, #16
	mov	sp, x8
	ldur	w10, [x9, #-16]
	ldr	w8, [x19, #12]
	add	w10, w10, #1
	stur	w10, [x9, #-16]
	tbnz	w8, #31, LBB0_1
	sub	w8, w8, #8
	cbz	w8, LBB0_1
	mov	x9, sp
	ldr	w8, [x19, #16]
	sub	x10, x9, #16
	mov	sp, x10
Lloh0:
	adrp	x10, _result@PAGE
Lloh1:
	add	x10, x10, _result@PAGEOFF
	mov	w12, #1
	ldr	w11, [x10]
	stur	w8, [x9, #-16]
	movk	w12, #512, lsl #16
	add	w13, w12, #3
	str	w8, [x11]
	mov	x8, sp
	sub	x11, x8, #16
	str	w13, [x19, #16]
	mov	sp, x11
	mov	x13, sp
	mov	w11, #1
	sub	x14, x13, #16
	stur	w11, [x8, #-16]
	mov	sp, x14
	stur	x10, [x13, #-16]
	mov	x10, sp
	sub	x14, x10, #16
	mov	sp, x14
	mov	x14, xzr
	ldr	w15, [x19, #16]
	mov	w16, w11
	ldur	x17, [x13, #-16]
	stur	w11, [x10, #-16]
	; InlineAsm Start
	mov	x16, x15
	mov	x0, x16
	mov	x1, x17
	mov	x2, x11
	mov	x3, x14
	mov	x4, x14
	mov	x5, x14
	svc	#0x80
	mov	x11, x0
	; InlineAsm End
	ldur	w9, [x9, #-16]
	ldur	x11, [x13, #-16]
	ldur	w10, [x10, #-16]
	str	w12, [x19, #16]
	stur	w9, [x8, #-16]
	; InlineAsm Start
	mov	x16, x12
	mov	x0, x9
	mov	x1, x11
	mov	x2, x10
	mov	x3, x14
	mov	x4, x14
	mov	x5, x14
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	sub	sp, x29, #16
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
