	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x28, x27, [sp, #-16]!
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	.cfi_def_cfa_offset 12336
	.cfi_offset w27, -8
	.cfi_offset w28, -16
	mov	w10, #1
	mov	w9, #1024
	mov	w11, #1
	movk	w10, #512, lsl #16
	str	w9, [sp, #8220]
	mov	w12, #13
	add	w9, w10, #3
	mov	x8, xzr
	stp	w12, w11, [sp, #8]
	stp	w9, wzr, [sp, #16]
	; InlineAsm Start
	mov	x16, x9
	mov	x0, x11
	mov	x1, x8
	mov	x2, x12
	mov	x3, x8
	mov	x4, x8
	mov	x5, x8
	svc	#0x80
	mov	x9, x0
	; InlineAsm End
	mov	w9, w12
	stp	wzr, w10, [sp, #12]
	; InlineAsm Start
	mov	x16, x10
	mov	x0, x8
	mov	x1, x8
	mov	x2, x9
	mov	x3, x8
	mov	x4, x8
	mov	x5, x8
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	add	sp, sp, #3, lsl #12
	add	sp, sp, #32
	ldp	x28, x27, [sp], #16
	ret
	.cfi_endproc

.subsections_via_symbols
