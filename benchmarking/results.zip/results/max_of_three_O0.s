	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #1024
	mov	w9, #17
	mov	w10, #42
	str	w8, [x19, #8220]
	mov	w8, #29
	stp	w9, wzr, [x19, #16]
	stp	w8, w10, [x19, #8]
	str	w9, [x19, #4]
	cbnz	wzr, LBB0_3
	mov	w8, #25
	cbz	w8, LBB0_3
	ldr	w8, [x19, #12]
	str	w8, [x19, #4]
LBB0_3:
	ldp	w9, w8, [x19, #4]
	cmp	w8, #0
	cset	w10, lt
	cmp	w9, #0
	cset	w11, lt
	eor	w10, w10, w11
	tbnz	w10, #0, LBB0_6
	sub	w8, w8, w9
	cbz	w8, LBB0_6
	ldr	w8, [x19, #8]
	str	w8, [x19, #4]
LBB0_6:
Lloh0:
	adrp	x9, _result@PAGE
Lloh1:
	add	x9, x9, _result@PAGEOFF
	ldr	w8, [x19, #4]
	ldr	w10, [x9]
	mov	w11, #1
	movk	w11, #512, lsl #16
	str	w8, [x10]
	mov	x8, sp
	add	w12, w11, #3
	sub	x10, x8, #16
	str	w12, [x19, #16]
	mov	sp, x10
	mov	x12, sp
	mov	w10, #1
	sub	x13, x12, #16
	stur	w10, [x8, #-16]
	mov	sp, x13
	mov	x13, xzr
	ldr	w14, [x19, #16]
	mov	w15, w10
	stur	x9, [x12, #-16]
	mov	w8, w10
	str	w10, [x19, #4]
	; InlineAsm Start
	mov	x16, x14
	mov	x0, x15
	mov	x1, x9
	mov	x2, x10
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x9, x0
	; InlineAsm End
	mov	w10, w10
	ldur	x9, [x12, #-16]
	str	w11, [x19, #16]
	; InlineAsm Start
	mov	x16, x11
	mov	x0, x8
	mov	x1, x9
	mov	x2, x10
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	sub	sp, x29, #16
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
