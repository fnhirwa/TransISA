	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	mov	w10, #48
	mov	w9, #18
LBB0_1:
	eor	w8, w9, w10
	cmp	w8, #0
	and	w11, w10, w8, asr #31
	csel	w8, wzr, w9, lt
	sub	w8, w10, w8
	sub	w9, w9, w11
	cmp	w8, w9
	mov	w10, w8
	b.ne	LBB0_1
Lloh0:
	adrp	x11, _result@PAGE
Lloh1:
	add	x11, x11, _result@PAGEOFF
	add	w10, w8, #48
	ldr	w12, [x11]
	mov	w13, #4
	mov	w15, #1
	mov	x9, xzr
	movk	w13, #512, lsl #16
	mov	w14, #1
	movk	w15, #512, lsl #16
	str	w10, [x12]
	; InlineAsm Start
	mov	x16, x13
	mov	x0, x14
	mov	x1, x11
	mov	x2, x14
	mov	x3, x9
	mov	x4, x9
	mov	x5, x9
	svc	#0x80
	mov	x10, x0
	; InlineAsm End
	; InlineAsm Start
	mov	x16, x15
	mov	x0, x8
	mov	x1, x11
	mov	x2, x14
	mov	x3, x9
	mov	x4, x9
	mov	x5, x9
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
