	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	brk	#0x1

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
