	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #1024
	mov	w9, #1
	str	xzr, [x19, #16]
	str	w8, [x19, #8220]
	mov	w8, #2
	stp	w8, w9, [x19, #8]
	mov	w8, #10
	str	w8, [x19, #4]
	b	LBB0_2
LBB0_1:
	ldr	w10, [x19, #16]
	ldr	w8, [x8]
	add	w9, w9, w10
	stp	w9, w8, [x19, #12]
	mov	x8, sp
	sub	x9, x8, #16
	mov	sp, x9
	ldur	w9, [x8, #-16]
	add	w9, w9, #1
	stur	w9, [x8, #-16]
LBB0_2:
	ldp	w9, w8, [x19, #4]
	mov	x15, sp
	ldr	w14, [x19, #12]
	sub	w10, w8, w9
	cmp	w10, #0
	cset	w11, lt
	cmp	w8, #0
	sub	x8, x15, #16
	cset	w12, lt
	cmp	w9, #0
	cset	w13, lt
	mov	sp, x8
	ldr	w9, [x19, #12]
	stur	w14, [x15, #-16]
	cbz	w10, LBB0_1
	eor	w12, w12, w13
	lsr	w10, w10, #31
	eor	w11, w12, w11
	cmp	w10, w11
	b.ne	LBB0_1
Lloh0:
	adrp	x11, _result@PAGE
Lloh1:
	add	x11, x11, _result@PAGEOFF
	mov	w13, #1
	ldr	w12, [x11]
	movk	w13, #512, lsl #16
	mov	x10, xzr
	str	x11, [x8]
	mov	w11, w11
	str	w9, [x12]
	add	w9, w13, #3
	mov	w12, #1
	str	w9, [x19, #16]
	str	w12, [x19, #4]
	; InlineAsm Start
	mov	x16, x9
	mov	x0, x11
	mov	x1, x11
	mov	x2, x12
	mov	x3, x10
	mov	x4, x10
	mov	x5, x10
	svc	#0x80
	mov	x9, x0
	; InlineAsm End
	ldr	w8, [x8]
	mov	w9, w12
	str	w13, [x19, #16]
	; InlineAsm Start
	mov	x16, x13
	mov	x0, x8
	mov	x1, x8
	mov	x2, x9
	mov	x3, x10
	mov	x4, x10
	mov	x5, x10
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	sub	sp, x29, #16
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
