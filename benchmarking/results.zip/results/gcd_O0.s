	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #32
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #1024
	mov	w9, #48
	str	w8, [x19, #8220]
	mov	w8, #18
	stp	w9, wzr, [x19, #16]
	b	LBB0_2
LBB0_1:
	ldp	w8, w9, [x19, #12]
	sub	w8, w8, w9
LBB0_2:
	str	w8, [x19, #12]
LBB0_3:
	ldp	w9, w8, [x19, #12]
	cmp	w8, w9
	b.eq	LBB0_6
	ldr	w9, [x19, #12]
	cmp	w8, #0
	cset	w8, lt
	cmp	w9, #0
	cset	w9, lt
	eor	w8, w8, w9
	tbnz	w8, #0, LBB0_1
	ldp	w9, w8, [x19, #12]
	sub	w8, w8, w9
	str	w8, [x19, #16]
	b	LBB0_3
LBB0_6:
	ldr	w9, [x19, #16]
Lloh0:
	adrp	x10, _result@PAGE
Lloh1:
	add	x10, x10, _result@PAGEOFF
	ldr	w11, [x10]
	str	w8, [x19, #12]
	mov	w8, #1
	add	w9, w9, #48
	movk	w8, #512, lsl #16
	str	w9, [x11]
	mov	x9, sp
	add	w12, w8, #3
	sub	x11, x9, #16
	str	w12, [x19, #16]
	mov	sp, x11
	mov	x12, sp
	mov	w11, #1
	sub	x13, x12, #16
	stur	w11, [x9, #-16]
	mov	sp, x13
	stur	x10, [x12, #-16]
	mov	x10, sp
	sub	x13, x10, #16
	mov	sp, x13
	mov	x13, xzr
	ldr	w14, [x19, #16]
	mov	w15, w11
	ldur	x16, [x12, #-16]
	stur	w11, [x10, #-16]
	; InlineAsm Start
	mov	x16, x14
	mov	x0, x15
	mov	x1, x16
	mov	x2, x11
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x11, x0
	; InlineAsm End
	ldr	w11, [x19, #12]
	ldur	x12, [x12, #-16]
	ldur	w10, [x10, #-16]
	str	w8, [x19, #16]
	stur	w11, [x9, #-16]
	; InlineAsm Start
	mov	x16, x8
	mov	x0, x11
	mov	x1, x12
	mov	x2, x10
	mov	x3, x13
	mov	x4, x13
	mov	x5, x13
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	sub	sp, x29, #16
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
