	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 16, 0
	.globl	__start
	.p2align	2
__start:
	.cfi_startproc
	stp	x28, x27, [sp, #-16]!
	sub	sp, sp, #3, lsl #12
	sub	sp, sp, #48
	.cfi_def_cfa_offset 12352
	.cfi_offset w27, -8
	.cfi_offset w28, -16
	mov	w9, #1024
	mov	w10, #10
	mov	w12, #1
	str	w9, [sp, #8236]
Lloh0:
	adrp	x9, _result@PAGE
Lloh1:
	add	x9, x9, _result@PAGEOFF
	ldr	w11, [x9]
	str	w10, [sp, #28]
	mov	w10, #63
	movk	w12, #512, lsl #16
	mov	x8, xzr
	str	x9, [sp, #16]
	str	w10, [x11]
	add	w10, w12, #3
	mov	w11, #1
	stp	w10, wzr, [sp, #32]
	str	w11, [sp, #24]
	str	w11, [sp, #12]
	; InlineAsm Start
	mov	x16, x10
	mov	x0, x11
	mov	x1, x9
	mov	x2, x11
	mov	x3, x8
	mov	x4, x8
	mov	x5, x8
	svc	#0x80
	mov	x9, x0
	; InlineAsm End
	mov	w10, w11
	ldr	x9, [sp, #16]
	str	w12, [sp, #32]
	str	wzr, [sp, #24]
	; InlineAsm Start
	mov	x16, x12
	mov	x0, x8
	mov	x1, x9
	mov	x2, x10
	mov	x3, x8
	mov	x4, x8
	mov	x5, x8
	svc	#0x80
	mov	x8, x0
	; InlineAsm End
	add	sp, sp, #3, lsl #12
	add	sp, sp, #48
	ldp	x28, x27, [sp], #16
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	_result
.zerofill __DATA,__common,_result,4,2
.subsections_via_symbols
